const music = document.getElementById("myAudio");
const Piu = document.getElementById("AudioPiu");
const PiuOther = document.getElementById("AudioPiuOther");

music.volume = 0.6;
Piu.volume = 0.2;
PiuOther.volume = 0.01;

const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const live = document.getElementById("lives");
const bulletMagazine = document.getElementById("bulletMagazine");
const Superbullet = document.getElementById("superBullet");
const s = document.getElementById("wave");

const startB = document.getElementById("Start");
const restartB = document.getElementById("Restart");

let processWave = 1;

let size = 45;
let sizeMannequin = 60;

let x = (canvas.width / 2) - (size / 2);
let y = (canvas.height - 100) - (size / 2);

let speed = 8;


let imgPlace = new Image();
imgPlace.src = "Moon.jpg";

let img = new Image();
img.src = "Space-Ship-2.png";

let imgBH = new Image();
imgBH.src = "image.png";

let imgBM = new Image();
imgBM.src = "imgBH.png";

let imgM = new Image();
imgM.src = "M.png";

let imgBoss = new Image();
imgBoss.src = "Boss.png";

let EffectImg = new Image();
EffectImg.src = "effect (2).png";

let goal = 5;
const startGoal = 5;
let score = 0;

let waveCleared = false;

let isPaused = false;
let startGame = true;
let restartGame = true;

let defeat = false;
let victory = false;

let bullets = [];
let bulletsM = [];
let Mannequins = [];
let effectS = [];

let lastTime = 0;
let shootTimer = 0;
let bulletReloadTimer = 0;
let regenTimer = 0;
let spawnTimer = 0;

const shootCooldown = 500;
const bulletReloadCooldown = 900;
const regenCooldown = 4500;
const spawnCooldown = 800;

let keys = new Set();

let Hero = {
    HP: 6,
    MaxHP: 6,
    MaxSizebulletsMagazine: 5,
    bulletsMagazine: 3,
    img: img,
    xH: x,
    yH: y,
    sizeHX: size,
    sizeHY: size
};

ctx.fillStyle = "White";
ctx.font = '44px "Press Start 2P"';
ctx.textAlign = "center";
ctx.fillText("Нажмите на кнопку старт(▶)", canvas.width / 2, canvas.height / 2);

music.addEventListener("ended", function () {
    music.currentTime = 0;
    music.play();
})

startB.addEventListener("click", function () {

    if (startGame) {
        startGame = false;
        requestAnimationFrame(gameLoop);
        startB.textContent = "⏸";
        music.play();
    }
    else{
        startGame = true;
        startB.textContent = "▶";
        music.pause();
        ctx.fillStyle = "White";
        ctx.font = '64px "Press Start 2P"';
        ctx.textAlign = "center";
        ctx.fillText("Пауза", canvas.width / 2, canvas.height / 2);
    }


    setTimeout(() => this.blur(), 1);
});

restartB.addEventListener("click", function () {
    
    if(defeat || victory){
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        Hero.HP = Hero.MaxHP;
        defeat = false;
        startGame = false;
        processWave = 1;
        score = 0;
        reset();
        music.currentTime = 0;
        music.play();
    }
    else{
        score = 0;
        goal = startGoal;
        bullets = [];
        bulletsM = [];
        Mannequins = [];
        effectS = [];
        Hero.xH = x;
        Hero.yH = y;
        processWave = 1;
        shootTimer = bulletReloadTimer = regenTimer = spawnTimer = 0;
        startGame = false;
        music.currentTime = 0;
        music.play();
    }
    setTimeout(() => this.blur(), 1);
});

document.addEventListener("keydown", function (e) {
    const key = e.key.toLowerCase();
    keys.add(key);
    if (key === " " && Hero.bulletsMagazine > 0) {
        Piu.currentTime = 0;
        Piu.play();
        Hero.bulletsMagazine--;
        bullets.push({
            x: Hero.xH + Hero.sizeHX / 2 - 10,
            y: Hero.yH,
            t: 0
        });
    }
});

document.addEventListener("keyup", function (e) {
    const key = e.key.toLowerCase();
    keys.delete(key);
});

function CheckBulletCollision() {
    Mannequins.forEach((mannequin, mannequinIndex) => {
        bullets.forEach((bullet, index) => {
            let bulletColl = { x: bullet.x, y: bullet.y, sizeW: 20, sizeH: 20 };
            let MannequinColl = {
                x: mannequin.xM,
                y: mannequin.yM,
                sizeW: mannequin.sizeMX,
                sizeH: mannequin.sizeMY
            };
            if (
                bulletColl.y <= MannequinColl.y + MannequinColl.sizeH &&
                bulletColl.y + bulletColl.sizeH >= MannequinColl.y &&
                bulletColl.x <= MannequinColl.x + MannequinColl.sizeW &&
                bulletColl.x + bulletColl.sizeW >= MannequinColl.x
            ) {
                bullets.splice(index, 1);
                mannequin.HP--;

                effectS.push({
                    x: mannequin.xM + 4,
                    y: mannequin.yM,
                    frame: 0,
                    timer: 0
                });

                if (mannequin.HP === 0) {
                    score++;
                    Mannequins.splice(mannequinIndex, 1);
                }
            }
        });
    });
}

function CheckBulletCollisionM() {
    bulletsM.forEach((bullet, index) => {
        let bulletColl = { x: bullet.x, y: bullet.y, sizeW: 20, sizeH: 20 };
        let HeroColl = {
            x: Hero.xH,
            y: Hero.yH,
            sizeW: Hero.sizeHX,
            sizeH: Hero.sizeHY
        };
        if (
            bulletColl.y - 10 <= HeroColl.y + HeroColl.sizeH &&
            bulletColl.y - 10 + bulletColl.sizeH >= HeroColl.y &&
            bulletColl.x <= HeroColl.x + HeroColl.sizeW &&
            bulletColl.x + bulletColl.sizeW >= HeroColl.x
        ) {
            bulletsM.splice(index, 1);
            Hero.HP--;

            effectS.push({
                x: HeroColl.x - 5,
                y: HeroColl.y - 20,
                frame: 0,
                timer: 0
            });
        }
    });
}

function spawnMannequin() {
    let randomPositionX = Math.floor(Math.random() * 1191) + 10;
    let randomPositionY = Math.floor(Math.random() * 391) + 10;

    if (processWave != 4){
        if (Mannequins.length < 6) {
            Mannequins.push({
                HP: 1,
                img: imgM,
                xM: randomPositionX,
                yM: randomPositionY,
                sizeMX: sizeMannequin,
                sizeMY: sizeMannequin,
                speedM: 6,
                goalMX: Math.floor(Math.random() * 1191) + 10,
                goalMY: Math.floor(Math.random() * 391) + 10,
                type: "simple"
            });
        }
    }
    else{
        if (Mannequins.length < 1){
            Mannequins.push({
                HP: 20,
                img: imgBoss,
                xM: randomPositionX,
                yM: randomPositionY,
                sizeMX: sizeMannequin + 60,
                sizeMY: sizeMannequin + 60,
                speedM: 8,
                goalMX: Math.floor(Math.random() * 1191) + 10,
                goalMY: Math.floor(Math.random() * 391) + 10,
                type: "boss"
            });
        
        }
    }
}

function moveMannequin() {
    Mannequins = Mannequins.filter(mannequin => {
        let xGoal = false;
        let yGoal = false;

        if(mannequin.xM > mannequin.goalMX){
            mannequin.xM -= mannequin.speedM;
            if(mannequin.xM < mannequin.goalMX) mannequin.xM = mannequin.goalMX;
        }
        else if(mannequin.xM < mannequin.goalMX){
            mannequin.xM += mannequin.speedM;
            if(mannequin.xM > mannequin.goalMX) mannequin.xM = mannequin.goalMX;
        }
        else xGoal = true;


        if(mannequin.yM > mannequin.goalMY){
            mannequin.yM -= mannequin.speedM;
            if(mannequin.yM < mannequin.goalMY) mannequin.yM = mannequin.goalMY;
        }
        else if(mannequin.yM < mannequin.goalMY){
            mannequin.yM += mannequin.speedM;
            if(mannequin.yM > mannequin.goalMY) mannequin.yM = mannequin.goalMY;
        }
        else yGoal = true;

        if(xGoal && yGoal){
            xGoal = false;
            yGoal = false;
            mannequin.goalMX = Math.floor(Math.random() * 1191) + 10;
            mannequin.goalMY = Math.floor(Math.random() * 391) + 10;
        }

        return mannequin.yM < canvas.height;
    });
}

function Shoot() {
    Mannequins.forEach(mannequin => {
        if (mannequin.HP > 0) {
            PiuOther.currentTime = 0;
            PiuOther.play();
            bulletsM.push({
                x: mannequin.xM + mannequin.sizeMX / 2 - 10,
                y: mannequin.yM,
                t: 0,
                type: mannequin.type
            });
        }
    });
}

function UpdateBulletMagazine() {
    if (Hero.bulletsMagazine < Hero.MaxSizebulletsMagazine) {
        Hero.bulletsMagazine++;
    }
}

function UpdateLives() {
    if (Hero.HP > 0 && Hero.HP < Hero.MaxHP) {
        Hero.HP++;
    }
}

function gameLoop(time = 0) {
    if (isPaused) return;
    if (startGame) return;
    if (defeat) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "Red";
        ctx.font = '44px "Press Start 2P"';
        ctx.textAlign = "center";
        ctx.fillText("Game over", canvas.width / 2, canvas.height / 2);
        music.pause();
        return;
    }

    const deltaTime = time - lastTime;
    lastTime = time;

    moveHero();

    live.textContent = `LIVES(💓): ${Hero.HP}`;
    bulletMagazine.textContent = `BULLETS: ${Hero.bulletsMagazine}`;
    Superbullet.textContent = `Уничтожено ${score}/${goal}`;
    s.textContent = processWave === 4 ? "Волна c боссом" : `Волна ${processWave}`;

    shootTimer += deltaTime;
    bulletReloadTimer += deltaTime;
    regenTimer += deltaTime;
    spawnTimer += deltaTime;

    if (shootTimer >= shootCooldown) {
        Shoot();
        shootTimer = 0;
    }

    if (bulletReloadTimer >= bulletReloadCooldown) {
        UpdateBulletMagazine();
        bulletReloadTimer = 0;
    }

    if (regenTimer >= regenCooldown) {
        UpdateLives();
        regenTimer = 0;
    }

    if (spawnTimer >= spawnCooldown) {
        spawnMannequin();
        spawnTimer = 0;
    }

    if(processWave === 1){
        goal = 5;
    }
    else if(processWave === 2){
        goal = 15;
    }
    else if(processWave === 3){
        goal = 20;
    }
    else if(processWave === 4){
        goal = 1;
    }

    if (score === goal) {
        if (!waveCleared && processWave !== 4) {
            panel();
            waveCleared = true;
            isPaused = true;

            setTimeout(() => {
                waveCleared = false;
                isPaused = false;
                reset();
            }, 5000);
            return;
        } else {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = "LightGreen";
            ctx.font = '44px "Press Start 2P"';
            ctx.textAlign = "center";
            ctx.fillText(`Игра пройдена. Поздравляю`, canvas.width / 2, canvas.height / 2);
            victory = true;
            music.pause();
            return;
        }
    }

    if (Hero.HP <= 0) {
        defeat = true;
    }

    game();
    requestAnimationFrame(gameLoop);
}

function reset() {
    requestAnimationFrame(gameLoop);
    score = 0;
    bullets = [];
    bulletsM = [];
    Mannequins = [];
    effectS = [];
    Hero.xH = x;
    Hero.yH = y;
    shootTimer = bulletReloadTimer = regenTimer = spawnTimer = 0;
}

function moveHero() {
    if ((keys.has("w") || keys.has("arrowup")) && Hero.yH > 0) Hero.yH -= speed;
    if ((keys.has("s") || keys.has("arrowdown")) && Hero.yH < canvas.height - size) Hero.yH += speed;
    if ((keys.has("a") || keys.has("arrowleft")) && Hero.xH > 0) Hero.xH -= speed;
    if ((keys.has("d") || keys.has("arrowright")) && Hero.xH < canvas.width - size) Hero.xH += speed;
    // if (keys.has(" ") ){
    //     bullets.push({
    //     x: Hero.xH + Hero.sizeHX / 2 - 10,
    //     y: Hero.yH,
    //     t: 0
    //     });
    // }
}

function game() {
    draw();
    UpdateBullets();
    UpdateBulletsM();
    moveMannequin();
    CheckBulletCollision();
    CheckBulletCollisionM();
    updateEffects(14);
}

function updateEffects(deltaTime) {
    const frameDuration = 50;
    effectS = effectS.filter(effect => {
        effect.timer += deltaTime;
        if (effect.timer >= frameDuration) {
            effect.frame++;
            effect.timer = 0;
        }
        return effect.frame < 3;
    });
}

function panel() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "LightGreen";
    ctx.font = '44px "Press Start 2P"';
    ctx.textAlign = "center";

    if (processWave <= 2) {
        ctx.fillText(`${processWave}-я волна пройдена`, canvas.width / 2, canvas.height / 2);
        processWave += 1;
    } else {
        ctx.fillText(`Волна с босом сейчас начнётся`, canvas.width / 2, canvas.height / 2);
        processWave += 1;
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(imgPlace, 0, 0, canvas.width, canvas.height);
    ctx.drawImage(Hero.img, Hero.xH, Hero.yH, Hero.sizeHX, Hero.sizeHY);

    Mannequins.forEach(mannequin => {
        ctx.drawImage(mannequin.img, mannequin.xM, mannequin.yM, mannequin.sizeMX, mannequin.sizeMY);
    });

    bullets.forEach(bullet => {
        ctx.drawImage(imgBH, bullet.x, bullet.y, 10, 30);
    });

    bulletsM.forEach(bullet => {
        ctx.drawImage(imgBM, bullet.x, bullet.y, 10, 30);
    });

    effectS.forEach(effect => {
        const frameWidth = 278;
        const frameHeight = 284;
        const scale = 0.3;
        ctx.drawImage(
            EffectImg,
            effect.frame * frameWidth, 0,
            frameWidth, frameHeight,
            effect.x, effect.y,
            frameWidth * scale, frameHeight * scale
        );
    });
}

function UpdateBullets() {
    bullets = bullets.filter(bullet => {
        bullet.t += 4;
        bullet.y -= bullet.t;
        return bullet.y >= 0;
    });
}

function UpdateBulletsM() {
    bulletsM = bulletsM.filter(bullet => {

        if(bullet.type === "boss"){
            if(bullet.x > Hero.xH) {
                bullet.x -= 6.5;
                if(bullet.x < Hero.xH) bullet.x = Hero.xH;
            }
            else if(bullet.x < Hero.xH) {
                bullet.x += 6.5;
                if(bullet.x > Hero.xH) bullet.x = Hero.xH;
            }
                
            if(bullet.y != Hero.yH)  bullet.y += 4;                  
        }
        else {bullet.y += 9;}
             
        return bullet.y <= canvas.height;
    });
}


// let size = 30;
// let sizeEnemy = 60;

// let x = canvas.width / 2;
// let y = canvas.height - 100;
// let yE = canvas.height / 2;
// let xE = canvas.width / 2 - (size/2);

// let speed = 5;

// let img = new Image();
// img.src = "Nikita.png";

// let imgE = new Image();
// imgE.src = "Child.png";

// let imgN = new Image();
// imgN.src = "Nikita.png";

// let imgF = new Image();
// imgF.src = "Огонь.png";

// let bullets = [];
// let bulletSpeed = 0.05;
// let bulletInterval = 500;

// let keys = new Set();

// setInterval(() => Shoot(1),bulletInterval);
// setInterval(() =>Shoot(2),bulletInterval);

// setInterval(() =>Shoot(3),bulletInterval + 500);
// setInterval(() =>Shoot(4),bulletInterval + 500);
// setInterval(() =>Shoot(5),bulletInterval + 500);
// setInterval(() =>Shoot(6),bulletInterval + 500);

// setInterval(() =>Shoot(7),bulletInterval + 500);
// setInterval(() =>Shoot(8),bulletInterval + 500);
// setInterval(() =>Shoot(9),bulletInterval + 500);
// setInterval(() =>Shoot(10),bulletInterval + 500);

// img.onload = imgE.onload = function(){
//     gameLoop();
// }

// function gameLoop(){
//     if((keys.has("w") || keys.has("arrowup"))&& y > 0){
//         y -= speed;
//     }

//     if((keys.has("s") || keys.has("arrowdown")) && y < (canvas.height - size)){
//         y += speed;
//     }

//     if((keys.has("a") || keys.has("arrowleft") )&& x > 0){
//         x -= speed;
//     }

//     if((keys.has("d") || keys.has("arrowright"))&& x < (canvas.width - size)){
//         x += speed;
//     }

//     draw();
//     UpdateBullets_Cycle();
//     requestAnimationFrame(gameLoop);
// }

// function draw(){
//     ctx.clearRect(0,0,canvas.width, canvas.height);
    
//     // ctx.fillStyle = "Blue";  //Всё это для зарисовки  
//     // ctx.fillRect(x,y,size + 10,size + 10);

//     ctx.drawImage(img,x,y,size,size);

//     ctx.drawImage(imgE,xE,yE,sizeEnemy,sizeEnemy);

//     bullets.forEach((bullet)=>{
//         ctx.fillStyle = "Red";
//         ctx.drawImage(imgF,bullet.x + 15,bullet.y + 28 ,40,40);
//     })
// }

// function Shoot(type){
//     bullets.push({
//         x: xE,
//         y: yE,
//         speedTurn: 0.15, // скорость поворота
//         speedR: 3,// рост радиуса
//         t: 0,
//         type: type 
//     });
// }

// function UpdateBullets_Cycle(){
//     bullets.forEach((bullet,index) => {
//         bullet.t += bullet.speedTurn;

//         let radius = bullet.t * bullet.speedR;
//         let turn = bullet.t * bullet.speedTurn;

//         if(bullet.type === 1){
//             bullet.x = xE - radius * Math.sin(turn);
//             bullet.y = yE - radius * Math.cos(turn);
//         }
//         else if(bullet.type === 2){
//             bullet.x = xE + radius * Math.sin(turn);
//             bullet.y = yE + radius * Math.cos(turn);
//         }
//         else if(bullet.type === 3){
//             bullet.x = xE + 10 * bullet.t;
//             bullet.y = yE + 10 * bullet.t;
//         }
//         else if(bullet.type === 4){
//             bullet.x = xE - 10 * bullet.t;
//             bullet.y = yE + 10 * bullet.t;
//         }
//         else if(bullet.type === 5){
//             bullet.x = xE - 10 * bullet.t;
//             bullet.y = yE - 10 * bullet.t;
//         }
//         else if(bullet.type === 6){
//             bullet.x = xE + 10 * bullet.t;
//             bullet.y = yE - 10 * bullet.t;
//         }

//         else if(bullet.type === 7){
//             bullet.x = xE + 10 * bullet.t;
//         }
//         else if(bullet.type === 8){
//             bullet.x = xE - 10 * bullet.t;
//         }
//         else if(bullet.type === 9){
//             bullet.y = yE - 10 * bullet.t;
//         }
//         else if(bullet.type === 10){
//             bullet.y = yE + 10 * bullet.t;
//         }

//         if(
//             bullet.x < 0 ||
//             bullet.x > canvas.width ||
//             bullet.y < 0||
//             bullet.y > canvas.height
//         )
//         {
//             bullets.splice(index,1);
//         }
//     });
// }

// document.addEventListener("keydown",function(e){
//     const key = e.key.toLowerCase();
//     keys.add(key);
// });

// document.addEventListener("keyup",function(e){
//     const key = e.key.toLowerCase();
//     keys.delete(key);
// });




///////////////////////////////////////////////////////////////////////////////
// class Game {
//     constructor(canvas, img) {
//       this.canvas = canvas;
//       this.ctx = canvas.getContext("2d");
//       this.score = 0;
//       this.img = img;
//       this.target = new Target(canvas.width, canvas.height, this.img);
  
//       this.canvas.addEventListener("click", this.handleClick.bind(this));
//     }
  
//     start() {
//       const loop = () => {
//         this.update();
//         requestAnimationFrame(loop);
//       };
//       loop();
//     }
  
//     update() {
//       this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  
//       this.target.draw(this.ctx);
  
//       document.getElementById("score").textContent = `Очки: ${this.score}`;
//     }
  
//     handleClick(event) {
//       const rect = this.canvas.getBoundingClientRect();
  
//       const mouseX = event.clientX - rect.left;
//       const mouseY = event.clientY - rect.top;
  
//       if (this.target.isClicked(mouseX, mouseY)) {
//         this.score++;
//         this.target = new Target(this.canvas.width, this.canvas.height, this.img);
//       }
  
//       this.update();
//     }
//   }
  
//   class Target {
//     constructor(canvasWidth, canvasHeight, img) {
//       this.radius = 50; // Радиус равен половине ширины/высоты изображения
//       this.x = Math.random() * (canvasWidth - 100); // Учитываем размер изображения
//       this.y = Math.random() * (canvasHeight - 100); // Учитываем размер изображения
//       this.img = img;
//     }
  
//     draw(ctx) {
//       ctx.drawImage(this.img, this.x, this.y, 100, 100); // Размер изображения 100x100
//     }
  
//     isClicked(mouseX, mouseY) {
//       const centerX = this.x + 50; // Центр изображения по X
//       const centerY = this.y + 50; // Центр изображения по Y
//       const distance = Math.hypot(mouseX - centerX, mouseY - centerY);
//       return distance <= 50; // Радиус равен половине ширины/высоты
//     }
//   }

// const canvas = document.getElementById("game");

// canvas.width = window.innerWidth;
// canvas.height = window.innerHeight;

// let imgN = new Image();
// imgN.src = "Nikita.png";

// let game = new Game(canvas,imgN);

// if (imgN.complete) {
//     game.start();
//   } else {
//     imgN.onload = function () {
//       game.start();
//     };
//   }



// let size = 30;
// let sizeEnemy = 60;

// let x = canvas.width / 2;
// let y = canvas.height - 100;
// let yE = canvas.height / 2;
// let xE = canvas.width / 2 - (size/2);

// let speed = 5;

// let img = new Image();
// img.src = "Nikita.png";

// let imgE = new Image();
// imgE.src = "Child.png";

// let imgN = new Image();
// imgN.src = "Nikita.png";

// let imgF = new Image();
// imgF.src = "Огонь.png";

// let bullets = [];
// let bulletSpeed = 0.05;
// let bulletInterval = 500;

// let keys = new Set();

// setInterval(() => Shoot(1),bulletInterval);
// setInterval(() =>Shoot(2),bulletInterval);

// setInterval(() =>Shoot(3),bulletInterval + 500);
// setInterval(() =>Shoot(4),bulletInterval + 500);
// setInterval(() =>Shoot(5),bulletInterval + 500);
// setInterval(() =>Shoot(6),bulletInterval + 500);

// setInterval(() =>Shoot(7),bulletInterval + 500);
// setInterval(() =>Shoot(8),bulletInterval + 500);
// setInterval(() =>Shoot(9),bulletInterval + 500);
// setInterval(() =>Shoot(10),bulletInterval + 500);

// img.onload = imgE.onload = function(){
//     gameLoop();
// }

// function gameLoop(){
//     if((keys.has("w") || keys.has("arrowup"))&& y > 0){
//         y -= speed;
//     }

//     if((keys.has("s") || keys.has("arrowdown")) && y < (canvas.height - size)){
//         y += speed;
//     }

//     if((keys.has("a") || keys.has("arrowleft") )&& x > 0){
//         x -= speed;
//     }

//     if((keys.has("d") || keys.has("arrowright"))&& x < (canvas.width - size)){
//         x += speed;
//     }

//     draw();
//     UpdateBullets_Cycle();
//     requestAnimationFrame(gameLoop);
// }

// function draw(){
//     ctx.clearRect(0,0,canvas.width, canvas.height);
    
//     // ctx.fillStyle = "Blue";  //Всё это для зарисовки  
//     // ctx.fillRect(x,y,size + 10,size + 10);

//     ctx.drawImage(img,x,y,size,size);

//     ctx.drawImage(imgE,xE,yE,sizeEnemy,sizeEnemy);

//     bullets.forEach((bullet)=>{
//         ctx.fillStyle = "Red";
//         ctx.drawImage(imgF,bullet.x + 15,bullet.y + 28 ,40,40);
//     })
// }

// function Shoot(type){
//     bullets.push({
//         x: xE,
//         y: yE,
//         speedTurn: 0.15, // скорость поворота
//         speedR: 3,// рост радиуса
//         t: 0,
//         type: type 
//     });
// }

// function UpdateBullets_Cycle(){
//     bullets.forEach((bullet,index) => {
//         bullet.t += bullet.speedTurn;

//         let radius = bullet.t * bullet.speedR;
//         let turn = bullet.t * bullet.speedTurn;

//         if(bullet.type === 1){
//             bullet.x = xE - radius * Math.sin(turn);
//             bullet.y = yE - radius * Math.cos(turn);
//         }
//         else if(bullet.type === 2){
//             bullet.x = xE + radius * Math.sin(turn);
//             bullet.y = yE + radius * Math.cos(turn);
//         }
//         else if(bullet.type === 3){
//             bullet.x = xE + 10 * bullet.t;
//             bullet.y = yE + 10 * bullet.t;
//         }
//         else if(bullet.type === 4){
//             bullet.x = xE - 10 * bullet.t;
//             bullet.y = yE + 10 * bullet.t;
//         }
//         else if(bullet.type === 5){
//             bullet.x = xE - 10 * bullet.t;
//             bullet.y = yE - 10 * bullet.t;
//         }
//         else if(bullet.type === 6){
//             bullet.x = xE + 10 * bullet.t;
//             bullet.y = yE - 10 * bullet.t;
//         }

//         else if(bullet.type === 7){
//             bullet.x = xE + 10 * bullet.t;
//         }
//         else if(bullet.type === 8){
//             bullet.x = xE - 10 * bullet.t;
//         }
//         else if(bullet.type === 9){
//             bullet.y = yE - 10 * bullet.t;
//         }
//         else if(bullet.type === 10){
//             bullet.y = yE + 10 * bullet.t;
//         }

//         if(
//             bullet.x < 0 ||
//             bullet.x > canvas.width ||
//             bullet.y < 0||
//             bullet.y > canvas.height
//         )
//         {
//             bullets.splice(index,1);
//         }
//     });
// }

// document.addEventListener("keydown",function(e){
//     const key = e.key.toLowerCase();
//     keys.add(key);
// });

// document.addEventListener("keyup",function(e){
//     const key = e.key.toLowerCase();
//     keys.delete(key);
// });




///////////////////////////////////////////////////////////////////////////////
// class Game {
//     constructor(canvas, img) {
//       this.canvas = canvas;
//       this.ctx = canvas.getContext("2d");
//       this.score = 0;
//       this.img = img;
//       this.target = new Target(canvas.width, canvas.height, this.img);
  
//       this.canvas.addEventListener("click", this.handleClick.bind(this));
//     }
  
//     start() {
//       const loop = () => {
//         this.update();
//         requestAnimationFrame(loop);
//       };
//       loop();
//     }
  
//     update() {
//       this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  
//       this.target.draw(this.ctx);
  
//       document.getElementById("score").textContent = `Очки: ${this.score}`;
//     }
  
//     handleClick(event) {
//       const rect = this.canvas.getBoundingClientRect();
  
//       const mouseX = event.clientX - rect.left;
//       const mouseY = event.clientY - rect.top;
  
//       if (this.target.isClicked(mouseX, mouseY)) {
//         this.score++;
//         this.target = new Target(this.canvas.width, this.canvas.height, this.img);
//       }
  
//       this.update();
//     }
//   }
  
//   class Target {
//     constructor(canvasWidth, canvasHeight, img) {
//       this.radius = 50; // Радиус равен половине ширины/высоты изображения
//       this.x = Math.random() * (canvasWidth - 100); // Учитываем размер изображения
//       this.y = Math.random() * (canvasHeight - 100); // Учитываем размер изображения
//       this.img = img;
//     }
  
//     draw(ctx) {
//       ctx.drawImage(this.img, this.x, this.y, 100, 100); // Размер изображения 100x100
//     }
  
//     isClicked(mouseX, mouseY) {
//       const centerX = this.x + 50; // Центр изображения по X
//       const centerY = this.y + 50; // Центр изображения по Y
//       const distance = Math.hypot(mouseX - centerX, mouseY - centerY);
//       return distance <= 50; // Радиус равен половине ширины/высоты
//     }
//   }

// const canvas = document.getElementById("game");

// canvas.width = window.innerWidth;
// canvas.height = window.innerHeight;

// let imgN = new Image();
// imgN.src = "Nikita.png";

// let game = new Game(canvas,imgN);

// if (imgN.complete) {
//     game.start();
//   } else {
//     imgN.onload = function () {
//       game.start();
//     };
//   }
